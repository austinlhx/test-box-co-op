# backend

To use...

1. Create a virtual environment, Docker container, or some mechanism to keep your Python requirements separate
2. `pip install -r requirements.txt`
3. Code!
4. Run `flask run` to start the server

